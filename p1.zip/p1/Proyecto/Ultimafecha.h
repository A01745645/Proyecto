#ifndef ULTIMAFECHA_C
#define ULTIMAFECHA_C
#include <iostream>
using namespace std;
class Ultimafecha
{
private:

    int dia {0};
    int mes {0};
    int aho {0000};

public:
    Ultimafecha() = default;
    Ultimafecha(int di, int me, int a){
        dia = di;
        mes = me;
        aho = a;
    }
    void setDia(int di){ dia = di ;}
    void setMes(int me){mes = me;}
    void setAho(int a){aho = a;}

    void dias(){
        if (dia > 31)
        {
            cout << "El dia no existe "<< endl;

        }
        if (dia < 0)
        {
            cout << "El dia no existe "<< endl;
        }
        
    }
    void meses(){
        if (mes > 12)
        {
            cout << " Este mes no existe " << endl;
        }
        if (mes < 1)
        {   
            cout << " Este mes no existe " << endl;
        }
        
    }
    
    
    void imprimef(){
        dias();
        meses();
        cout << "La ultima fecha de el examen fue " << dia << "/" << mes << "/" << aho << endl;
    }
};



#endif