#ifndef EDAD_C
#define EDAD_C
#include <iostream>
using namespace std;
class Edad
{
private:
    int edad;
    int edad3d;
    int edadinf;
public:
    Edad() = default;

    Edad(int e,int e3, int ei){
       edad = e;
       edad3d = e3;
       edadinf = ei;
    }
    void tresedad(){
        if (edad > edad3d)
        {
            cout << "Persona de la tercera edad" << endl;
        }
        
    }
    void infante(){
        if (edad < edadinf)
        {
            cout << "Esta persona es un infante" << endl;
        }
        
    }
    void imrprimee(){
        cout << "Esta persona tiene " << edad << " años" << endl;
        tresedad();
        infante();
    }
};

#endif