#ifndef TERMOMETRO_C
#define TERMOMETRO_C
#include <iostream>
#include <string>
using namespace std;
class Termometro
{
private:
    float temperatura{5.6};
    int maximotemp{0};
    int mintemp{0};
public:
    Termometro() = default;
    Termometro(float t, int max, int min){
        temperatura = t;
        maximotemp = max;
        mintemp = min;
    }
    float getTemperatura(){return temperatura;}
    int getMaximotemp(){return maximotemp;}
    int getMintemp(){return mintemp;}

    void setTemperatura(float t){temperatura = t;}
    void setMaximotemp(int max){maximotemp = max;}
    void setMintemp(int min){mintemp = min;}

    void efe(){
        float faren;
        faren = (temperatura*1.8)+32;
        cout << "La temperatura en fahrenheit " << faren << endl;
    }


    void riesgocovid(){
        if (temperatura > 37)
        {
          cout << "Esta persona esta en riesgo de tener covid" << endl; 
        }
        else
        {
            cout << "Esta persona es menos probable de que tenga covid" << endl;
        }
        
    }
    void riesgotemp(){
        if (temperatura > maximotemp)
        {
            cout << "Tal vez tenga covid pero la temperatura tan alta es por algo peor" << endl;
        }
        if (temperatura < mintemp)
        {
            cout << "Esta persona tiene muy baja temperatura" << endl;
        }
        
    }
    void imprimet(){
        cout << "La temperatura es de " << temperatura << " grados" << endl;
        cout << "La maxima temperatura para detectar problemas mas fuertes es de " << maximotemp << " grados" << endl;
        cout << "La temperatura minima antes de preocuparse es de " << mintemp << " grados" << endl;
        riesgocovid();
        riesgotemp();
        efe();
    }


};



#endif