#include <iostream>
using namespace std;
#include "Pantalla.h"
int main()
{
    
    Termometro t2{36.5,40,20}; //Aqui se mandan las variables a la clase de termometro//
    Ultimafecha f2{3,5,2020};//Aqui se mandan las variables a la clase fecha//
    informacion inf2{true,false,f2};//Aqui se manda la variable de fecha ya creada junto con los nuevos valores para la clase informacion//
    Edad ed1{73,60,12};//Se meten las variables a la clase edad//
    Pantalla p2{t2,inf2,ed1};//Con las variables dadas se manda la variable de informacion, de edad y termometro a la clase pantalla//
    p2.imprimep();//un metodo que imprime todo//
    
    


    return 0;
}
