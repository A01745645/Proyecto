#ifndef INFORMACION_C
#define INFORMACION_C
#include "Ultimafecha.h"
#include <iostream>
using namespace std;
class informacion
{
private:
    Ultimafecha fecha;
    bool contagio;
    bool personariesgo;

public:
    informacion() = default;
    informacion(bool c, bool pdr, Ultimafecha f){
        contagio = c;
        personariesgo = pdr;
        fecha = f;
    }
    void setContagio(bool c){contagio = c;}
    void setPersonariesgo(bool pdr){personariesgo = pdr;}

    void ultimoresultado(bool res){
        setContagio(res);
    }
    void personade(){
        if (personariesgo == true)
        {
            cout << "Esta persona es una persona de riesgo" << endl;
        }
        else
        {
            cout << "No es una persona de riesgo" << endl;
        }
        
    }
    void estacont(){
        if (contagio == true)
        {
            cout << "Esta persona en su ultimo examen estaba contagiado" << endl;
        }
        else
        {
            cout << "Esta persona en su ultimo esamen no estaba contagiado" << endl;
        }
        
        
    }

        
    
    void imprimei(){
        fecha.imprimef();
        personade();
        estacont();

        
    }
};


#endif 