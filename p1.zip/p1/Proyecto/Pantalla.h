#ifndef PANTALLA_C
#define PANTALLA_C
#include <iostream>
using namespace std;
#include "Termometro.h"
#include "informacion.h"
#include "Edad.h"//Los includes de los archivos .h//
class Pantalla
{
private:
    Termometro t1;
    informacion info;
    Edad ed;//Las variables de instancia//
    int base{50};
    int altura{20};
    
public:
    Pantalla()= default;
    Pantalla(Termometro t, informacion in, Edad eda){//Constructor de la clase pantalla que recibe los datos proporcionados en el main//
        t1 = t;
        info = in;
        ed = eda;//
    }
    void perimetro(){//Clase que saca el perimetro//
        int perri;
        perri = (2*base)+(2*altura);
        cout << "El perimetro de la pantalla es " << perri << endl;//Tiene su cout para que se imprima solo mandando llamar al metodo//
    }
    void area (){//Metodo para sacar el area de la pantalla//
        int arrrea;
        arrrea = base*altura;
        cout << "El area de la pantalla es "<< arrrea << endl;//Igual tiene cout para que imprima tan solo llamar al metodo//
    }
    
    void imprimep(){//Metodo iprime que manda a llamar a los otros metodos imprime juntando todos en un solo metodo//
        t1.imprimet();
        info.imprimei();
        ed.imrprimee();
        perimetro();
        area();

    }
};



#endif
